[
    {
        "ID": "M1322465",
        "Name": "Dogman",
        "Author": "Mike M",
        "Publisher": "Sunshine" 
    },
    {
        "ID": "J5112014",
        "Name": "Cat in the Hat",
        "Author": "Jane J",
        "Publisher": "Rainy Day"
    },
    {
        "ID": "P8597411",
        "Name": "Cat in the Hat",
        "Author": "Pete P",
        "Publisher": "Sunshine"
    },
]